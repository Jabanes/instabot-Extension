// config.js
window.ENV = {
    BACKEND_BASE_URL: "https://igbot-prod.onrender.com/check-bot-status"
  };
  